﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace SortiranjeKrugova
{
    public partial class Form1 : Form
    {
        public struct Krug
        {
            public int r;
            public Color boja;
        }

        Krug[] a;
        int n;
        
        private void Heap(int levi, int desni)
        {
            int i, j;
            bool gotovo = false;

            i = levi;
            j = 2 * i + 1;
            Krug temp = a[i];
            while ((j <= desni) && !gotovo)
            {
                //biramo veceg od sinova ako postoji
                if (j < desni)  //postoje dva sina
                {
                    if (a[j].r < a[j + 1].r)
                    {
                        j++;
                    }
                }
                if (a[j].r <= temp.r)
                    gotovo = true;
                else
                {
                    a[i] = a[j];
                    i = j;
                    j = 2 * i + 1;
                }
            }
            a[i] = temp;
        }
        private void HeapSort(Krug[] a, int n)
        {
            //Najpre napraviti prioritetnu listu
            int levi, desni;
            levi = n / 2;
            desni = n - 1;
            while (levi > 0)
            {
                levi--;
                Heap(levi, desni);
            }
            //Redom prebacivati najvece elemente na kraj prioritetne liste
            while (desni > 0)
            {
                razmeni(ref a[0], ref a[desni]);
                desni--;
                Heap(0, desni);

            }

        }

        private void razmeni(ref Krug x, ref Krug y)
        {
            Krug pom = x;
            x = y;
            y = pom;
        }
        public Form1()
        {
            InitializeComponent();
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {
            
            StreamReader s = new StreamReader("krug.txt");
            n = Convert.ToInt32(s.ReadLine());
            a = new Krug[n];
            int i = 0;
            while (!s.EndOfStream)
            {
                string linija = s.ReadLine();
                string[] niz = linija.Split();
                a[i].r = Convert.ToInt32(niz[0]);
                a[i].boja = Color.FromArgb(Convert.ToInt32(niz[1]), Convert.ToInt32(niz[2]), Convert.ToInt32(niz[3]));
                i++;
            }
            s.Close();

            
            
        }

        

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            int x = 20;
            int y = ClientRectangle.Height / 2;
            for (int i = 0; i < n; i++)
            {
                x += a[i].r;
                SolidBrush cetka=new SolidBrush(a[i].boja);
                g.FillEllipse(cetka, x - a[i].r, y - a[i].r, a[i].r * 2, a[i].r * 2);
                x += a[i].r;
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            HeapSort(a, n);
            Refresh();
        }

       
        
    }
}
